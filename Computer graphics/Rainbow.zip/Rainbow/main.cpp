#include <windows.h>
#include <GL/glut.h>

void display(){
    glClearColor(1.0f,1.0f,1.0f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.55,-0.7);
    glVertex2f(-0.5,-0.7);
    glVertex2f(-0.5,0.7);
    glVertex2f(-0.55,0.7);


    glVertex2f(-0.65,-0.8);
    glVertex2f(-0.4,-0.8);
    glVertex2f(-0.4,-0.7);
    glVertex2f(-0.65,-0.7);


    glColor3ub(102, 0, 204);
    glVertex2f(-0.5,0.6);
    glVertex2f(0.5,0.6);
    glVertex2f(0.5,0.7);
    glVertex2f(-0.5,0.7);

    glColor3ub(0, 0, 102);
    glVertex2f(-0.5,0.5);
    glVertex2f(0.5,0.5);
    glVertex2f(0.5,0.6);
    glVertex2f(-0.5,0.6);

    glColor3ub(0, 153, 204);
    glVertex2f(-0.5,0.4);
    glVertex2f(0.5,0.4);
    glVertex2f(0.5,0.5);
    glVertex2f(-0.5,0.5);

    glColor3ub(0, 255, 0);
    glVertex2f(-0.5,0.3);
    glVertex2f(0.5,0.3);
    glVertex2f(0.5,0.4);
    glVertex2f(-0.5,0.4);

    glColor3ub(255, 255, 0);
    glVertex2f(-0.5,0.2);
    glVertex2f(0.5,0.2);
    glVertex2f(0.5,0.3);
    glVertex2f(-0.5,0.3);

    glColor3ub(255, 127, 0);
    glVertex2f(-0.5,0.1);
    glVertex2f(0.5,0.1);
    glVertex2f(0.5,0.2);
    glVertex2f(-0.5,0.2);

    glColor3ub(255, 0, 0);
    glVertex2f(-0.5,0);
    glVertex2f(0.5,0);
    glVertex2f(0.5,0.1);
    glVertex2f(-0.5,0.1);



    glEnd();
    glFlush();
}

int main(int argc,char** argv){
    glutInit(&argc,argv);
    glutCreateWindow("Rainbow");
    glutInitWindowSize(320,320);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
